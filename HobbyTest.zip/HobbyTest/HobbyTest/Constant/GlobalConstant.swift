//
//  GlobalConstant.swift
//  HobbyTest
//
//  Created by appbellmac on 10/05/19.
//  Copyright © 2019 Sagar Rathode. All rights reserved.
//

import Foundation
struct  GlobalConstants{
  static let BORDER_COLOR = "000000"
}
