//
//  CategoryData.swift
//  HobbyTest
//
//  Created by appbellmac on 14/05/19.
//  Copyright © 2019 AppBell Technologies Pvt Ltd. All rights reserved.
//

import Foundation
class CategoryData: NSObject {
    var id = Int()
    var name = String()
}
